const net = require('net');
var target = {
  host: 'localhost',
  port: 2345
};
