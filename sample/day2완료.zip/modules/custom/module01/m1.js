console.log('m1.js 로딩됨.');
// 기본값
// module.exports = {};
module.exports = {
  name: 'm1',
  type: 'object'
};