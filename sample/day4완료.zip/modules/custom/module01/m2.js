exports.name = 'm2.js';
exports.type = 'object';