module.exports = {
  name: 'index.js',
  type: 'object'
};