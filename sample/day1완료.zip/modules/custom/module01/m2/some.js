var name = 'some.js';
var type = 'object';
module.exports = {
  name: name,
  type
};